import android.app.PendingIntent
import android.content.Intent
import android.nfc.*
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.nfc.ui.theme.NFCTheme
import android.nfc.tech.NfcA
import android.nfc.tech.NfcB
import android.nfc.tech.NfcF
import android.nfc.tech.NfcV
import android.nfc.tech.IsoDep
import android.nfc.tech.MifareClassic
import android.nfc.tech.MifareUltralight
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import android.Manifest

class MainActivity : ComponentActivity() {

    private lateinit var nfcAdapter: NfcAdapter
    private var nfcStatus by mutableStateOf("Esperando etiqueta NFC...")

    private val PERMISSION_REQUEST_CODE = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Verifica y solicita permisos de NFC si es necesario
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.NFC) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.NFC), PERMISSION_REQUEST_CODE)
        }

        // Inicializar el adaptador NFC
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        if (nfcAdapter == null || !nfcAdapter.isEnabled) {
            Toast.makeText(this, "NFC no está habilitado o no es compatible en este dispositivo", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        setContent {
            NFCTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .padding(16.dp),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = nfcStatus,
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()

        // Configurar PendingIntent para la detección de etiquetas NFC
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT
        )
        nfcAdapter.enableForegroundDispatch(this, pendingIntent, null, null)
    }

    override fun onPause() {
        super.onPause()
        nfcAdapter.disableForegroundDispatch(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (NfcAdapter.ACTION_TAG_DISCOVERED == intent.action) {
            val tag: Tag? = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)
            tag?.let {
                // Detecta tecnologías soportadas por la etiqueta NFC
                val techList = detectTechnologies(it)
                nfcStatus = "Tecnologías de NFC detectadas:\n$techList"
            }
        }
    }

    private fun detectTechnologies(tag: Tag): String {
        val techList = mutableListOf<String>()
        if (NfcA.get(tag) != null) techList.add("NfcA")
        if (NfcB.get(tag) != null) techList.add("NfcB")
        if (NfcF.get(tag) != null) techList.add("NfcF")
        if (NfcV.get(tag) != null) techList.add("NfcV")
        if (IsoDep.get(tag) != null) techList.add("IsoDep")
        if (MifareClassic.get(tag) != null) techList.add("MifareClassic")
        if (MifareUltralight.get(tag) != null) techList.add("MifareUltralight")

        if (techList.isEmpty()) {
            techList.add("No se detectaron tecnologías compatibles.")
        }
        return techList.joinToString(separator = "\n")
    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    NFCTheme {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(text = "Esperando etiqueta NFC...")
        }
    }
}
